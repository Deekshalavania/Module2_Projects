package com.cg.hr;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/*The context parameters are accessible to all web components in an application
	Servlets,JSP,Filters,Listeners.(one object per application)
	Declare common value like:CompanyName,URL of other applications etc
  The config parameters.These are not accessible to all servlets.These are p
     	are private to one server.
     	Get them from ServletConfig
     	Accessible to  only a parent web component.
     	Not accessible to any other web component.
      
*/

//@WebServlet("/MyServlet01")
public class MyServlet01 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext ctx= super.getServletContext(); //GenricServlet getmethod
		String companyName=ctx.getInitParameter("companyName");
		System.out.println(companyName);
		
		ServletConfig config=super.getServletConfig();//GenricServlet getmethod
		String pageTitle=config.getInitParameter("pageTitle");
		System.out.println("Page title: "+pageTitle);
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
