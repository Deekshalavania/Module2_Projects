import java.util.Date;
import java.util.HashSet;
import java.util.Set;


import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.dto.Product;
import com.cg.ems.dto.Supplier;
import com.cg.ems.util.JPAUtil;

public class TestOneToOneDemo {
	public static void main(String[] args) {
		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Product p1=new Product();
		p1.setProductCode(100);
		p1.setProductName("TV");
		p1.setProductPrice(35000);
		
		Product p2=new Product();
		p2.setProductCode(200);
		p2.setProductName("Refrigerator");
		p2.setProductPrice(56000);
		
		Product p3=new Product();
		p3.setProductCode(300);
		p3.setProductName("CD");
		p3.setProductPrice(200);
		
		Product p4=new Product();
		p4.setProductCode(400);
		p4.setProductName("Laptop Bag");
		p4.setProductPrice(85000);
		
		Set<Product> elecProdSet=new HashSet<Product>();
		elecProdSet.add(p1);
		elecProdSet.add(p2);
		elecProdSet.add(p3);
		
		Supplier sony=new Supplier();
		sony.setSupplierId(111);
		sony.setSupplyDate(new Date());
		sony.setProductSet(elecProdSet);
		
		Supplier lg=new Supplier();
		lg.setSupplierId(112);
		lg.setSupplyDate(new Date(2019,12,04));
		lg.setProductSet(elecProdSet);
		
		Set<Supplier> supplierSet=new HashSet<Supplier>();
		supplierSet.add(sony);
		supplierSet.add(lg);
	
		
		
		Set<Product> bag=new HashSet<Product>();
		bag.add(p4);
		
		et.begin();
		em.persist(sony);
		et.commit();
		System.out.println("Product is Persist");
		
		}

}
