import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.util.JPAUtil;

public class TestInheritanceDemo 
{
	public static void main(String args[]) {
Emp rahul=new Emp();
rahul.setEmpName("Rahul chauhan");
rahul.setEmpsal(678780.0f);


Manager vaishali=new Manager();
vaishali.setEmpName("Vaishalis");
vaishali.setEmpsal(5000.0f);
vaishali.setDeptName("java");
EntityManager em=JPAUtil.getEntityManager();
EntityTransaction tran=em.getTransaction();
 tran.begin();
 em.persist(rahul);
 em.persist(vaishali);
 tran.commit();
System.out.println("data is inserted");
Manager ee1=em.find(Manager.class, 87);
System.out.println(ee1);

}
}