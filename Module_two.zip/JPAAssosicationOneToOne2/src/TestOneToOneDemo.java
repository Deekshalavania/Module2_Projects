import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.dto.Address;
import com.cg.ems.dto.Student;
import com.cg.ems.util.JPAUtil;

public class TestOneToOneDemo {

	public static void main(String[] args)
	{
      EntityManager em=JPAUtil.getEntityManager();
      EntityTransaction et=em.getTransaction();
      

  
	}

}
