package com.cg.ems.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Address
{
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
@Column(name="addressId",length=10)
private int addressId;
@Column(name="city",length=50)
private String city;
@Column(name="zip_code",length=6)
private String zipcode;
@Column(name="state",length=25)
private String state;
@Column(name="street",length=25)
private String street;
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getZipcode() {
	return zipcode;
}
public void setZipcode(String zipcode) {
	this.zipcode = zipcode;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public int getAddressId() {
	return addressId;
}
public void setAddressId(int addressId) {
	this.addressId = addressId;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
@Override
public String toString() {
	return "Address [city=" + city + ", zipcode=" + zipcode + ", state=" + state + ", addressId=" + addressId
			+ ", street=" + street + "]";
}
public Address() {
	super();

}
public Address(String city, String zipcode, String state, int addressId, String street) {
	super();
	this.city = city;
	this.zipcode = zipcode;
	this.state = state;
	this.addressId = addressId;
	this.street = street;
}

}
