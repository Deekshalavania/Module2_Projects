package com.cg.ems.bean;

public class Employee {
	private static int empId;
	private static String empName;
	private static float empSal;
	private static String empDesg;
	private static String empIns;
	public static int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public static String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public static float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public static String getEmpDesg() {
		return empDesg;
	}
	public static String getEmpIns() {
		return empIns;
	}
	public void setEmpIns(String empIns) {
		this.empIns = empIns;
	}
	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String empName, float empSal, String empDesg) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesg = empDesg;
	}
	@Override
	public String toString() {
		return "Employee [empIns=" + empIns + "]";
	}
	

}
