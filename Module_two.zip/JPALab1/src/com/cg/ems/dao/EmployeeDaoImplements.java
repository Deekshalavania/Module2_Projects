package com.cg.ems.dao;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ems.bean.Employee;
import com.cg.ems.service.IEmployee;
import com.cg.ems.util.DBUtil;

public class EmployeeDaoImplements implements IEmployeeDao {
int queryResult=0;
	@Override
	public int addDetails(Employee e) throws SQLException, IOException {
	Connection con=DBUtil.getCon();
	PreparedStatement preState=null;
	CallableStatement callState=null;
	ResultSet rst=null;
	preState=con.prepareStatement(QueryMapper.INSERT_QUERY);
	preState.setInt(1,Employee.getEmpId());		
	preState.setString(2,Employee.getEmpName());	
	preState.setFloat(3,Employee.getEmpSal());	
	preState.setString(4,Employee.getEmpDesg());	
   preState.setString(5,Employee.getEmpIns());
   queryResult=preState.executeUpdate();
   return queryResult;
	}
	
	

	

	@Override
	public Employee deleteDetails(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateDetails(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee fetchById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
