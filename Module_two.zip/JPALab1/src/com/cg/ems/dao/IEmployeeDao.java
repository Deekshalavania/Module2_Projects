package com.cg.ems.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.cg.ems.bean.Employee;

public interface IEmployeeDao 
{
	int addDetails(Employee e) throws SQLException, IOException;
	Employee deleteDetails(int id);
	Employee updateDetails(int id);
	Employee fetchById(int id);
	Employee getAll();
}
