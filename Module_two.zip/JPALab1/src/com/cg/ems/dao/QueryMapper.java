package com.cg.ems.dao;

import com.cg.ems.bean.Employee;

public class QueryMapper {


	public static final String RETRIVE_ALL_QUERY="Select empId,empName,empDesg,empSal,empIns from employeeInsurance";
	public static final String VIEW_EMPLOYEE_DETAILS_BYID="SELECT * from employeeInsurance WHERE empId=?";
	public static final String INSERT_QUERY="INSERT INTO employeeInsurance VALUES(?,?,?,?)";
    public static final String UPDATE_QUERY="UPDATE employeeInsurance SET empName=?,empSal=? where empId=?";
    public static final String DELETE_QUERY="DELETE * from employeeInsurance where empId=?";
}


