package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.EmployeeDaoImplements;
import com.cg.ems.dao.IEmployeeDao;

public class EmployeeServiceImplements implements IEmployee 
{
 IEmployeeDao dao=null;
 public EmployeeServiceImplements()
 {
	 dao= new EmployeeDaoImplements();
 }
	@Override
	public int addDetails(Employee e) throws SQLException, IOException {
		return dao.addDetails(e);
	}

	@Override
	public Employee deleteDetails(int id) {
		return dao.deleteDetails(id);
	}

	@Override
	public Employee updateDetails(int id) {
		return dao.updateDetails(id);
	}

	@Override
	public Employee fetchById(int id) {
	return dao.fetchById(id);
	}

	@Override
	public Employee getAll() {
	  return dao.getAll();
	}

}
