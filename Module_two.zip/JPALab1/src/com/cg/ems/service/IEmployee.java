package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;

import com.cg.ems.bean.Employee;

public interface IEmployee
{
int addDetails(Employee e) throws SQLException, IOException;
Employee deleteDetails(int id);
Employee updateDetails(int id);
Employee fetchById(int id);
Employee getAll();
}
