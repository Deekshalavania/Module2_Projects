package com.cg.ems.ui;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Scanner;

import com.cg.ems.bean.Employee;
import com.cg.ems.service.EmployeeServiceImplements;
import com.cg.ems.service.IEmployee;
import com.cg.ems.util.DBUtil;

public class Main {
   static Employee e=new Employee();
	IEmployee serv;
	try {
	Connection con=DBUtil.getCon();
	CallableStatement cst=con.prepareCall("Call pr1(?,?)");
	public Main()
	{
		serv=new EmployeeServiceImplements();
	}
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		e.setEmpId(scanner.nextInt());
		e.setEmpName(scanner.next());
		e.setEmpSal(scanner.nextFloat());
		e.setEmpDesg(scanner.next());
		e.setEmpIns();
		
		
    

	}

}
