package com.cg.bms.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="author1")
public class Author 
{
	@Id
@Column(name="auth_id",length=10)
private int id;
@Column(name="auth_name",length=25)
private String authName;
@ManyToMany(mappedBy="authSet")


/*@ManyToMany(cascade=CascadeType.ALL)
@JoinTable(name="book_author",
joinColumns= {
		@JoinColumn(name="book_isn")},
inverseJoinColumns=
{@JoinColumn(name="auth_id")})*/

Set<Book> bookSet=new HashSet();
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getAuthName() {
	return authName;
}
public void setAuthName(String authName) {
	this.authName = authName;
}

public Set<Book> getBookSet() {
	return bookSet;
}
public void setBookSet(Set<Book> bookSet) {
	this.bookSet = bookSet;
}
@Override
public String toString() {
	return "Author [id=" + id + ", authName=" + authName + ", bookSet=" + bookSet + "]";
}
public Author() {
	super();
	// TODO Auto-generated constructor stub
}
public Author(int id, String authName, Set<Book> bookSet) {
	super();
	this.id = id;
	this.authName = authName;
	this.bookSet = bookSet;
}




}
