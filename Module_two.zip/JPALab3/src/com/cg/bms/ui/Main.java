 package com.cg.bms.ui;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.bms.bean.Author;
import com.cg.bms.bean.Book;
import com.cg.bms.util.JPAUtil;

public class Main 
{
public static void main(String args[])
{
	EntityManager em=JPAUtil.getEntityManager();
	EntityTransaction et=em.getTransaction();
	
	/*Book b1=new Book();
	b1.setIsbn(111);
	b1.setTitle("ABC");
	b1.setPrice(4477.0f);
	
	Book b2=new Book();
	b2.setIsbn(112);
	b2.setTitle("DEF");
	b2.setPrice(53.0f);
	
	Book b3=new Book();
	b3.setIsbn(113);
	b3.setTitle("GHI");
	b3.setPrice(877.0f);
	
	
	Set<Book> bookHash=new HashSet<Book>();
	bookHash.add(b1);
	bookHash.add(b2);
	bookHash.add(b3);
	
	Author a1=new Author();
	a1.setId(222);
	a1.setAuthName("Riya");
	a1.setBookSet(bookHash);
   
	Author a2=new Author();
	a2.setId(333);
	a2.setAuthName("Hari");

 
	
	Set<Author> authHash=new HashSet<Author>();
	authHash.add(a1);
	//authHash.add(a2);
		
  
	et.begin();
	em.persist(a1);
	
	et.commit();
	
	System.out.println("Data is Inserted");*/
	Author a1=new Author();
	a1.setId(222);
	a1.setAuthName("Riya");

	Set<Author> authHash=new HashSet<Author>();
	authHash.add(a1);
	
	Book b1=new Book();
	b1.setIsbn(111);
	b1.setTitle("ABC");
	b1.setPrice(4477.0f);
	b1.setAuthSet(authHash);
	
	Book b2=new Book();
	b2.setIsbn(112);
	b2.setTitle("DEF");
	b2.setPrice(53.0f);
	b2.setAuthSet(authHash);
	
	Book b3=new Book();
	b3.setIsbn(113);
	b3.setTitle("GHI");
	b3.setPrice(877.0f);
	b3.setAuthSet(authHash);
	
	Set<Book> bookHash=new HashSet<Book>();
	bookHash.add(b1);
	bookHash.add(b2);
	bookHash.add(b3);
	et.begin();
	em.persist(b1);
	em.persist(b2);
	em.persist(b3);
	
	et.commit();
	
	System.out.println("Data is Inserted");
	
	
}
	
}
