package com.cg.bms.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="book1new")
public class Book {
	@Id
	@Column(name="book_isbn",length=20)
	private int isbn;
	@Column(name="book_title",length=25)
	private String title;
	@Column(name="book_price",length=20)
	private float price;
	/*@ManyToMany(mappedBy="bookSet")*/
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="book_author_new",
	joinColumns= {
			@JoinColumn(name="book_isn")},
	inverseJoinColumns=
	{@JoinColumn(name="auth_id")})
	Set<Author> authSet=new HashSet<>();
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Set<Author> getAuthSet() {
		return authSet;
	}
	public void setAuthSet(Set<Author> authSet) {
		this.authSet = authSet;
	}
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", price=" + price + ", authSet=" + authSet + "]";
	}
	public Book(int isbn, String title, float price, Set<Author> authSet) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.price = price;
		this.authSet = authSet;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	
	
}
