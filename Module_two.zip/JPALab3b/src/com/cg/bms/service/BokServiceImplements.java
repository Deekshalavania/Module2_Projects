package com.cg.bms.service;

import java.util.ArrayList;

import com.cg.bms.bean.Author;
import com.cg.bms.bean.Book;
import com.fg.bms.dao.BookDaoImplements;
import com.fg.bms.dao.IBookDao;

public class BokServiceImplements implements IBookService{

	IBookDao dao=null;
	public BokServiceImplements()
	{
		dao=new BookDaoImplements();
	}
	@Override
	public Author addAuthor(Author a) {

		return dao.addAuthor(a);
	}
	@Override
	public Book addBook(Book b) {
	
		return dao.addBook(b);
	}
	@Override
	public ArrayList<Book> viewAll() {

		return dao.viewAll();
	}
	@Override
	public Book viewByAuthor(String authName) {
	
		return dao.viewByAuthor(authName);
	}
	@Override
	public ArrayList<Book> priceBetween(int price1, int price2) {
	
		return dao.priceBetween(price1, price2);
	}
	@Override
	public Author nameAuthor(int bookISBN) {
	
		return dao.nameAuthor(bookISBN);
	}

}
