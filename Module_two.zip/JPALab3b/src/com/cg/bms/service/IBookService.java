package com.cg.bms.service;

import java.util.ArrayList;

import com.cg.bms.bean.Author;
import com.cg.bms.bean.Book;

public interface IBookService 
{
Author addAuthor(Author a);
Book addBook(Book b);
ArrayList<Book> viewAll();
Book viewByAuthor(String authName);
ArrayList<Book> priceBetween(int price1,int price2);
Author nameAuthor(int bookISBN);
}

