package com.cg.bms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bms.bean.Author;
import com.cg.bms.bean.Book;
import com.cg.bms.service.BokServiceImplements;
import com.cg.bms.service.IBookService;

public class Main 
{
static IBookService serv=new BokServiceImplements();
public static void main(String args[])
{
while(true)
{ 
	Scanner scanner=new Scanner(System.in);
	int choice=scanner.nextInt();
	System.out.println("==========================================================");

	System.out.println("Press any key");
	System.out.println("==========================================================");

	System.out.println("1.ADD Author\n2.Add Book\n3.View All Book\n4.View "
			+ "Book By AuthorName\n4.Book between prices\n5.View Author By Book ISBN");
	System.out.println("----------------------------------------------------------");
	switch(choice)
	{
	case 1:System.out.println("Enter Author Id");	
		  int id=scanner.nextInt();
		  System.out.println("Enter Author Name");
		  String name=scanner.next();
		  Author a=new Author();
		  a.setId(id);
		  a.setAuthName(name);
		  Author aa=serv.addAuthor(a);
		  System.out.println("Author Data inserted"+a);
		  break;
	case 2:System.out.println("Enter Book ISBN");	
	  	  int isbn=scanner.nextInt();
	      System.out.println("Enter book Name");
	      String bname=scanner.next();
	      System.out.println("Enter Book Price");	
	  	  Float price=scanner.nextFloat();
	      Book b=new Book();
	      b.setIsbn(isbn);
	      b.setTitle(bname);
	      b.setPrice(price);
	      Book bb=serv.addBook(b);
	      System.out.println("Book Data inserted"+b);
		  break;
	case 3:System.out.println("Fetched Records");
			ArrayList<Book> view=serv.viewAll();
			System.out.println(view);
			break;
	case 4:System.out.println("Enter the author name whose Book you want to see");
		   String authName=scanner.next();
		   Book bbb=serv.viewByAuthor(authName);
		   System.out.println(bbb);
		   break;
	case 5:System.out.println("Enter price 1");
			int p1=scanner.nextInt();
			System.out.println("Enter price 2");
			int p2=scanner.nextInt();
			ArrayList<Book> priceBook=serv.priceBetween(p1, p2);	
			System.out.println(priceBook);
			break;
	case 6:System.out.println("Enter Book ISBN");
			int is=scanner.nextInt();
			Author aaaaa=serv.nameAuthor(is);
			System.out.println(aaaaa);
			break;
	default:System.out.println("BYE...BYE....");
	        System.exit(0);
	        break;
			
	
	
	}
}
}
}