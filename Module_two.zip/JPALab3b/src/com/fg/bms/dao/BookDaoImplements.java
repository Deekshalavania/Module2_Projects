package com.fg.bms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.bms.bean.Author;
import com.cg.bms.bean.Book;
import com.cg.bms.util.JPAUtil;



public class BookDaoImplements implements IBookDao
{
  EntityManager em=null;
  EntityTransaction et=null;
  public BookDaoImplements()
  {
	  em=JPAUtil.getEntityManager();
	  et=em.getTransaction();
  }
	
	@Override
	public Author addAuthor(Author a) {
	et.begin();
	em.persist(a);
	et.commit();
	return a;
	}

	@Override
	public Book addBook(Book b) {

		et.begin();
		em.persist(b);
		et.commit();
		return b;
	}

	@Override
	public ArrayList<Book> viewAll() {
		String selAllQry="Select b from book1 b"; 
		TypedQuery<Book> tq=em.createQuery(selAllQry,Book.class);
		ArrayList<Book> bookList=(ArrayList)tq.getResultList();
		return bookList;
	}

	@Override
	public Book viewByAuthor(String authName) {
		Book b=em.find(Book.class,authName);
		return b;
	}

	@Override
	public ArrayList<Book> priceBetween(int price1, int price2) {
		String price="Select b from book b where price BTWEEN price1 AND price2";
		TypedQuery<Book> tq=em.createQuery(price,Book.class);
		ArrayList<Book> bookList=(ArrayList)tq.getResultList();
		return bookList;
	}

	@Override
	public Author nameAuthor(int bookISBN) {
	  
		Author a=em.find(Author.class,bookISBN);
		return a;
	 
	}

	
}
