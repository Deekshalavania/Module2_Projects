package com.fg.bms.dao;

import java.util.ArrayList;

import com.cg.bms.bean.Author;
import com.cg.bms.bean.Book;

public interface IBookDao {
	Author addAuthor(Author a);
	Book addBook(Book b);
	ArrayList<Book> viewAll();
	Book viewByAuthor(String authName);
	ArrayList<Book> priceBetween(int price1,int price2);
	Author nameAuthor(int bookISBN);
}
