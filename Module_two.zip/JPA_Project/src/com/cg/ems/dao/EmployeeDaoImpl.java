package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.ems.bean.Employee;
import com.cg.ems.util.JPAUtil;

public class EmployeeDaoImpl implements EmployeeDao 
{
   EntityManager em=null;
   EntityTransaction entityTran=null; // for managing transaction
   public EmployeeDaoImpl()
   {
	   em=JPAUtil.getEntityManager();
	   entityTran=em.getTransaction();
	   
   }
	@Override
	public Employee addEmp(Employee emp) 
	{
		entityTran.begin();
		em.persist(emp);// for Insert we use persist
		entityTran.commit();
		return emp;
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		String selAllQry="Select emps from Employee emps"; 
		TypedQuery<Employee> tq=em.createQuery(selAllQry,Employee.class);
		ArrayList<Employee> empList=(ArrayList)tq.getResultList();
		return empList;
		//Select emp from Employee emp where emp.empID=112;
	}

	@Override
	public Employee deleteEmp(int empId) 
	{
		Employee e1=em.find(Employee.class,empId);
		entityTran.begin();
	em.remove(e1);
	entityTran.commit();
	return e1;
	}

	@Override
	public Employee getEmpByEid(int empId) {
		Employee ee=em.find(Employee.class,empId); //Here ee is in manage State
		return ee;
	}

	@Override
	public Employee updateEmp(int empId, String newName, float NewSal) {
		Employee ee=em.find(Employee.class,empId);
		ee.setEmpName(newName);
		ee.setEmpSal(NewSal);
		entityTran.begin();
		em.merge(ee);
		entityTran.commit();
		return ee;
		
	}

}
