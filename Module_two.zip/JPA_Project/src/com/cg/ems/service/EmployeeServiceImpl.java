package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDao empDao=null;
	public EmployeeServiceImpl()
	{
		empDao=new EmployeeDaoImpl();
	}

	@Override
	public Employee addEmp(Employee emp) {
		
		return empDao.addEmp(emp);
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		return empDao.fetchAllEmp();
	}

	@Override
	public Employee deleteEmp(int empId) {
	
		return empDao.deleteEmp(empId);
	}

	@Override
	public Employee getEmpByEid(int empId) 
	{
	
		return empDao.getEmpByEid(empId);
	}

	@Override
	public Employee updateEmp(int empId, String newName, float NewSal) 
	{
		
		return empDao.updateEmp(empId, newName, NewSal);
	}

}
