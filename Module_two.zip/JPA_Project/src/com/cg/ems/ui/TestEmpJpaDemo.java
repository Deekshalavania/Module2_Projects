package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.bean.Employee;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class TestEmpJpaDemo {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		EmployeeService empSer=new EmployeeServiceImpl();
		Employee e1=new Employee();
	/*	FOR ADDING BY AUTOMATI GENERTOR AND CONSTRUCTOR SEPARATELY
	  e1.setEmpName("Deeksha");
        e1.setEmpSal(90000.0f);
		Employee e1=new Employee(113,"Tanu Sharma",4500.0f,null);
		Employee e2=new Employee(114,"Vikas Agarwal",89000.0f,null);
		Employee ee1=empSer.addEmp(e1);
	Employee ee2=empSer.addEmp(e2);
	System.out.println(ee1 +"\n and" +ee2);
		System.out.println(ee1 +"\n are inserted");
		*/
		
		
/*	Employee ee=empSer.getEmpByEid(scanner.nextInt());
	System.out.println(ee);*/
	
/*	System.out.println("=============Fetched Records=============");
	ArrayList<Employee> eList=empSer.fetchAllEmp();
	for(Employee tempE:eList)
	{
		System.out.println(tempE.getEmpId()+"\t"+tempE.getEmpName()+"\t"+tempE.getEmpSal());
	}*/
	/*
	System.out.println("=========Delete-=============");
	Employee deletedEmp=empSer.deleteEmp(82);
    System.out.println(deletedEmp+ "deleted");*/
		
	System.out.println("==========Updated Data==========");
	Employee ee=empSer.updateEmp(83, "Omansh Lavania",900000.0f);
	System.out.println("Updated Employee is"+ee);
	}

}
