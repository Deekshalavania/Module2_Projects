package com.cg.hr.core.dao;

import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.exceptions.EmpException;

public interface EmployeeDao 
{
	ArrayList<Employee> fetchAllEmp()  throws EmpException;

	Employee getEmpByEid(int empId) throws EmpException;
}
