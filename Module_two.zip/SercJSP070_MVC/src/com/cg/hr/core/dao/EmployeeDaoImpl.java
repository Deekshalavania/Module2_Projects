package com.cg.hr.core.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.exceptions.EmpException;
import com.cg.hr.util.JDBCUtil;
import com.cg.hr.util.JPAUtil;


public class EmployeeDaoImpl implements EmployeeDao 
{
private Connection connect;   
   public EmployeeDaoImpl() throws EmpException
   {
	   JDBCUtil util=new JDBCUtil();
	   connect=util.getConnect();
	   
   }
 
	/*@Override
	public Employee addEmp(Employee emp) 
	{
		entityTran.begin();
		em.persist(emp);// for Insert we use persist
		entityTran.commit();
		return emp;
	}*/

	@Override
	public ArrayList<Employee> fetchAllEmp() throws EmpException {
		Statement stmt=null;
		ResultSet rs=null;
		ArrayList<Employee> empList=new ArrayList<>();
		try {
			
			stmt=connect.createStatement();
			rs=stmt.executeQuery("Select emp_id,emp_name,emp_sal from emp1");
			while(rs.next())
			{
				int empNo=rs.getInt("emp_id");
				String empNm=rs.getString("emp_name");
				float empSal=rs.getFloat("emp_sal");
				Employee emp=new Employee(empNo,empNm,empSal);
				empList.add(emp);
			}
			return empList;
		} catch (Exception e) {
			throw new EmpException("Something wrong in fetchAll",e);
			
		}
		finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(stmt!=null)
				{
					stmt.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}

	@Override
	protected void finalize() throws Throwable {
		if(connect!=null) {
		connect.close();
		}
		super.finalize();
	}

	/*@Override
	public Employee deleteEmp(int empId) 
	{
		Employee e1=em.find(Employee.class,empId);
		entityTran.begin();
	em.remove(e1);
	entityTran.commit();
	return e1;
	}*/

	@Override
	public Employee getEmpByEid(int empId) throws EmpException 
	{
		Employee emp=null;
		PreparedStatement stmt=null;
		
		ResultSet rs=null;
	  
		try {
			
			stmt=connect.prepareStatement("Select emp_id,emp_name,emp_sal from emp1 where emp_id=?");
			stmt.setInt(1,empId);
			rs=stmt.executeQuery();
			while(rs.next())
			{
				int empNo=rs.getInt("emp_id");
				String empNm=rs.getString("emp_name");
				float empSal=rs.getFloat("emp_sal");
			   emp=new Employee(empNo,empNm,empSal);
				
			}
			return emp;
		} catch (Exception e) {
			throw new EmpException("Something wrong in fetchAll",e);
			
		}
		finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(stmt!=null)
				{
					stmt.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/*@Override
	public Employee updateEmp(int empId, String newName, float NewSal) {
		Employee ee=em.find(Employee.class,empId);
		ee.setEmpName(newName);
		ee.setEmpSal(NewSal);
		entityTran.begin();
		em.merge(ee);
		entityTran.commit();
		return ee;
		
	}*/

}
