package com.cg.hr.core.service;

import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.exceptions.EmpException;

public interface EmployeeSercvice 
{
	ArrayList<Employee> fetchAllEmp()  throws EmpException;
	Employee getEmpByEid(int empId) throws EmpException;

}
