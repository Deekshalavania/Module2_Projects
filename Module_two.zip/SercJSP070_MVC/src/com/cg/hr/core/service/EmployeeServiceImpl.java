package com.cg.hr.core.service;

import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.dao.EmployeeDao;
import com.cg.hr.core.dao.EmployeeDaoImpl;
import com.cg.hr.core.exceptions.EmpException;

public class EmployeeServiceImpl implements EmployeeSercvice {
    private EmployeeDao dao;
	public EmployeeServiceImpl () throws EmpException
	{
		dao=new EmployeeDaoImpl();
	}
	@Override
	public ArrayList<Employee> fetchAllEmp() throws EmpException {
		
		return dao.fetchAllEmp();
	}
	@Override
	public Employee getEmpByEid(int empId) throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpByEid(empId);
		}

}
