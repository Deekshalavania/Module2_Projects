package com.cg.hr;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//Pick Up Query String data (GET)for insensitive data and faster(consumes less resources)
    //Pick Up Form Data         (POST)for sensitive data and slower
   	String userName=request.getParameter("userName");
    	String password=request.getParameter("password");
          RequestDispatcher dispatch=null;
    	//For multiple Data String=request.getParameter(arg0)
    	if(userName.equals("Vishwendra")&&(password.equals("singh")))
    	{
    		String fullName="Vishwendra Singh Rawat";
    		
    		//Request Scope
    		request.setAttribute("fullName",fullName);
    		dispatch=request.getRequestDispatcher("/WEB-INF/Pages/MainMenu.jsp");
    	}
    	else
    	{
    		request.setAttribute("message","Wrong Authentication....Please do Again!!");
    		dispatch=request.getRequestDispatcher("/WEB-INF/Pages/Login.jsp");
    	}
    	dispatch.forward(request, response);
    	System.out.println("User Name: "+userName);
	}

}
