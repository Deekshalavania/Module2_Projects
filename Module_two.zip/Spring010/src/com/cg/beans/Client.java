package com.cg.beans;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
public static void main(String args[])
{

	Resource res=new ClassPathResource("beans.xml");
	XmlBeanFactory factory=new XmlBeanFactory(res);
	
	Employee emp1=(Employee) factory.getBean("e1");
	Employee emp2=(Employee) factory.getBean("e2");
	UserCredentials creden=(UserCredentials) factory.getBean("cred");
	
	System.out.println(emp1);
	System.out.println(emp2);

	System.out.println(creden);
	
}
}
