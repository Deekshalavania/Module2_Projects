package com.cg.beans;

import java.util.Map;

public class UserCredentials {

	Map<String,String> credentials;

	public Map<String, String> getCredentials() {
		return credentials;
	}

	public void setCredentials(Map<String, String> credentials) {
		this.credentials = credentials;
	}

	@Override
	public String toString() {
		return "UserCredentials [credentials=" + credentials + "]";
	}
	
	
}
